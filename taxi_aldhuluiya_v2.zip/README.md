# تكسي الضلوعية - النسخة المطورة

هذه نسخة Web جاهزة للمعاينة، وتحتوي على ثلاث واجهات:
- `index.html` للراكب
- `driver.html` للسائق
- `admin.html` للإدارة

## المعاينة
افتح `index.html` في المتصفح.
النسخة تعمل محليًا وتحفظ الطلبات على الجهاز باستخدام localStorage.

## تحويلها إلى نظام متعدد الأجهزة
الخطوة التالية هي إنشاء مشروع Firebase ثم وضع بيانات المشروع في `firebase-config.js`، وبعدها ربط الطلبات والسائقين بـ Firestore وFirebase Authentication.

## النشر على Firebase Hosting
1. ثبّت Firebase CLI.
2. سجّل الدخول: `firebase login`
3. داخل مجلد المشروع نفّذ: `firebase init hosting`
4. اختر مجلد المشروع كمجلد public.
5. نفّذ: `firebase deploy`

ملاحظة: ملف `firestore.rules` الحالي مغلق عمدًا حتى لا تصبح قاعدة البيانات مكشوفة. يجب إضافة قواعد مصادقة مناسبة قبل تشغيل Firebase فعليًا.
