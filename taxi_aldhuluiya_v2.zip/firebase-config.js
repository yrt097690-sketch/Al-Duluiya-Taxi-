// ضع بيانات مشروع Firebase هنا عند إنشاء المشروع.
// الموقع يعمل أيضًا بوضع المعاينة المحلية باستخدام localStorage.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
window.FIREBASE_ENABLED = false;
