(function(){
const KEY='taxiOrdersV2', DRIVER='taxiDriverV2';
const getOrders=()=>JSON.parse(localStorage.getItem(KEY)||'[]');
const saveOrders=x=>localStorage.setItem(KEY,JSON.stringify(x));
const esc=x=>String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const id=()=> 'TX-'+Date.now().toString().slice(-7);
function initPassenger(){
 const gps=document.getElementById('gps'), time=document.getElementById('time'), custom=document.getElementById('customTime'), req=document.getElementById('request'); let coords=null;
 time.onchange=()=>custom.classList.toggle('hidden',time.value!=='custom');
 gps.onclick=()=>{if(!navigator.geolocation)return alert('المتصفح لا يدعم GPS'); document.getElementById('coords').textContent='⏳ جارٍ تحديد الموقع...'; navigator.geolocation.getCurrentPosition(p=>{coords={lat:p.coords.latitude,lng:p.coords.longitude};document.getElementById('coords').textContent=`✅ تم تحديد الموقع: ${coords.lat.toFixed(6)}, ${coords.lng.toFixed(6)}`},()=>document.getElementById('coords').textContent='❌ لم يتم السماح بالموقع');};
 req.onclick=()=>{let name=document.getElementById('name').value.trim(),phone=document.getElementById('phone').value.trim(),pickup=document.getElementById('pickup').value.trim(),destination=document.getElementById('destination').value.trim(); if(!name||!phone||!pickup||!destination)return alert('أكمل البيانات المطلوبة.'); const o={id:id(),name,phone,pickup,destination,coords,time:time.value==='custom'?custom.value:time.value,notes:document.getElementById('notes').value.trim(),status:'pending',created:new Date().toLocaleString('ar-IQ')}; const a=getOrders();a.unshift(o);saveOrders(a);document.getElementById('status').classList.remove('hidden');document.getElementById('status').textContent='✅ تم إرسال الطلب رقم '+o.id; renderLast();};
 renderLast();
}
function renderLast(){const o=getOrders()[0], el=document.getElementById('lastOrder');if(!el)return;if(!o){el.textContent='لا يوجد طلب بعد.';return}el.innerHTML=`<b>${esc(o.id)}</b><br>من: ${esc(o.pickup)}<br>إلى: ${esc(o.destination)}<br><span class="badge">${label(o.status)}</span>`;}
function label(s){return ({pending:'بانتظار السائق',accepted:'تم قبول الطلب',onway:'السائق بالطريق',done:'مكتمل',cancelled:'ملغى'})[s]||s}
function initDriver(){
 const d=JSON.parse(localStorage.getItem(DRIVER)||'null'); if(d){for(const [k,v] of Object.entries(d)){const e=document.getElementById(k==='name'?'driverName':k==='phone'?'driverPhone':k==='carNumber'?'carNumber':'carType');if(e)e.value=v}state();}
 document.getElementById('saveDriver').onclick=()=>{const d={name:driverName.value.trim(),phone:driverPhone.value.trim(),carNumber:carNumber.value.trim(),carType:carType.value.trim(),available:true};if(!d.name||!d.phone||!d.carNumber)return alert('أكمل بيانات السائق.');localStorage.setItem(DRIVER,JSON.stringify(d));state();alert('تم حفظ بيانات السائق.');};
 document.getElementById('availability').onclick=()=>{let d=JSON.parse(localStorage.getItem(DRIVER)||'null');if(!d)return alert('احفظ بيانات السائق أولاً');d.available=!d.available;localStorage.setItem(DRIVER,JSON.stringify(d));state();};
 function state(){const d=JSON.parse(localStorage.getItem(DRIVER)||'null');document.getElementById('driverState').textContent=d?(d.available?'🟢 السائق متاح':'🔴 السائق غير متاح'):'غير مسجل';}
 renderDriver(); setInterval(renderDriver,1500);
}
function renderDriver(){const el=document.getElementById('orders');if(!el)return;const a=getOrders().filter(o=>o.status==='pending');if(!a.length){el.innerHTML='<div class="hint">لا توجد طلبات بانتظار سائق.</div>';return}el.innerHTML=a.map(o=>`<article class="order"><b>${esc(o.id)}</b><p>👤 ${esc(o.name)} — ${esc(o.phone)}</p><p>📍 ${esc(o.pickup)}</p><p>🏁 ${esc(o.destination)}</p><button class="primary" onclick="TaxiApp.accept('${o.id}')">قبول الطلب</button></article>`).join('');}
function accept(oid){const a=getOrders(),i=a.findIndex(x=>x.id===oid);if(i<0)return;a[i].status='accepted';saveOrders(a);renderDriver();alert('تم قبول الطلب '+oid);}
function initAdmin(){renderAdmin();setInterval(renderAdmin,1500)}
function renderAdmin(){const a=getOrders(), all=document.getElementById('allCount');if(!all)return;document.getElementById('allCount').textContent=a.length;document.getElementById('pendingCount').textContent=a.filter(x=>x.status==='pending').length;document.getElementById('activeCount').textContent=a.filter(x=>['accepted','onway'].includes(x.status)).length;document.getElementById('adminOrders').innerHTML=a.length?a.map(o=>`<article class="order"><b>${esc(o.id)}</b><p>${esc(o.name)} | ${esc(o.phone)}</p><p>📍 ${esc(o.pickup)} → 🏁 ${esc(o.destination)}</p><span class="badge">${label(o.status)}</span></article>`).join(''):'<div class="hint">لا توجد طلبات.</div>';const d=JSON.parse(localStorage.getItem(DRIVER)||'null');document.getElementById('drivers').innerHTML=d?`<article class="order"><b>${esc(d.name)}</b><p>${esc(d.phone)} — سيارة ${esc(d.carNumber)}</p><span class="badge">${d.available?'متاح':'غير متاح'}</span></article>`:'<div class="hint">لا يوجد سائق مسجل على هذا الجهاز.</div>';}
window.TaxiApp={initPassenger,initDriver,initAdmin,accept};
})();
